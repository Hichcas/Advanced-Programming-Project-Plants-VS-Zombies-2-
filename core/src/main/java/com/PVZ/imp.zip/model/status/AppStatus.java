package com.PVZ.model.status;

import com.PVZ.model.enums.MenuType;
import com.PVZ.model.enums.PlantType;
import com.PVZ.model.user.User;

import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;

public final class AppStatus {

    private AppStatus() {
    }

    public static final Scanner scanner = new Scanner(System.in);
    public static MenuType currentMenuType = MenuType.REGISTER;
    public static User currentUser = null;
    public static String currentChapterName = null;
    public static final Set<PlantType> selectedPlants = new LinkedHashSet<>();
    public static final Set<PlantType> boostedPlants = new LinkedHashSet<>();
}
